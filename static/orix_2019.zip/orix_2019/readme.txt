Author yuji MITSUKAWA
References https://baseball-freak.com/game/19/buffaloes.html